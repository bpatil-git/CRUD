from django.urls import path
from app1 import views

urlpatterns = [
    path('', views.Student_view, name='home'),
    path('add/', views.add_and_show, name='add_show'),
    path('update/<int:id>/', views.update, name='update'),
    path('delete/<int:id>/', views.delete_data, name='delete'),

]

from django.shortcuts import render, redirect
from .forms import StudentRegistration
from .models import User

# Create your views here.

def Student_view(request):
    return redirect('add_show')

# This function will add and show student list.
def add_and_show(request):
    if request.method == 'POST':
        fm = StudentRegistration(request.POST, request.FILES)
        if fm.is_valid():
            nm = fm.cleaned_data['name']
            em = fm.cleaned_data['email']
            pw = fm.cleaned_data['password']
            im = fm.cleaned_data['img']
            reg = User(name=nm, email=em, password=pw, img=im)
            reg.save()
            return redirect('add_show')
    else:
        fm = StudentRegistration()
    stud = User.objects.all()
    return render(request, 'app1/addandshow.html', {'form': fm, 'stu': stud})
# This function updaye/edit data
def update(request, id):
    if request.method == 'POST':
        pi = User.objects.get(pk=id)
        fm = StudentRegistration(request.POST, request.FILES, instance=pi)
        if fm.is_valid():
            fm.save()
            return redirect('add_show')
    else:
        pi = User.objects.get(pk=id)
        fm = StudentRegistration(instance=pi)
    return render(request, 'app1/update.html', {'st_update': fm})


# This function will delete student record
def delete_data(request, id):
    if request.method == 'POST':
        pi = User.objects.get(pk=id)
        pi.delete()
        return redirect('add_show')
